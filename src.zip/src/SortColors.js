import './App.css';
import React from 'react';
const listColors = ["#CC66CC","#C6C","#CC33CC","#C3C","#993399","#939","#660066","#606"]
class SortColors extends React.Component {


  constructor(props){
    super(props)

    this.onAddItem = props.onAddItem
    this.state = {
      color:''
   }
  }




  onSort = () =>{
    let colorSort = listColors[Math.floor(Math.random() * listColors.length)]
    this.onAddItem(colorSort)
    this.setState({ 
        color: colorSort
    })
  }

  sortFiveTimes = () =>{
    for (var i = 0; i <= 4; i++){
  }
}

  render(){
    
    return (

      <>
        Memorize a sequencia de cores: <br/>
        <div onClick={this.onSort} style={{backgroundColor: this.state.color}}>HS</div>


      </>

    );
  }
}

export default SortColors;
