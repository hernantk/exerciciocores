import './App.css';
import React from 'react';
import SortColors from './SortColors';
import ListColors from './ListColors';



class App extends React.Component {


  constructor(props){
    super(props)
    this.state = {
      listColors : [],
      listColorsSeleted : [],
      winner : false,
      loser :false
   }
  }


  handleInput=(event)=>{
    this.setState({
      [event.target.name]:event.target.value
    })
  }

  addItemToListColors = (color) =>{
    this.setState(currentState =>({
      listColors:[...currentState.listColors,color],
    } ))
  }

  addItemToListColorsSelected = (color) =>{
    if(this.state.listColorsSeleted.length<5){
    this.setState(currentState =>({
      listColorsSeleted:[...currentState.listColorsSeleted,color],
    } ))}
  }

  checkColors=()=>{
    for (var i = 0; i <= 4; i++){
      if(this.state.listColorsSeleted[i]!==this.state.listColors[i]){
        return false
      }
    }
    return true
  }

  validade = () =>{
    if(this.checkColors()){
      this.setState({
        winner:true
      })   }
    else{
      this.setState({
        loser:true
      })  } }

  erase = () =>{
    this.setState(currentState =>({
      listColors:[],
      listColorsSeleted:[],
      winner:false,
      loser :false
    } ))
  }


  render(){
    
    return (

      <>
      {this.state.listColors.length <5 && <SortColors onAddItem={this.addItemToListColors}></SortColors>}

      <ul>
        {
          this.state.listColorsSeleted.map((item,index) => <li style={{backgroundColor:item}} key={index}>{item}</li>)
        }
      </ul>
        
      {this.state.listColors.length ===5 && <ListColors selectColor={this.addItemToListColorsSelected} items={this.state.listColors}/>}

      <button disabled={this.state.listColorsSeleted.length !==5} onClick={this.validade}>Validar</button>

      {this.state.winner &&  <p>Parabens você Acertou</p>}
      {this.state.loser &&  <p>Você Errou</p>}
  

      {this.state.winner && <button onClick={this.erase}>Jogar Novamente</button>}
      {this.state.loser && <button onClick={this.erase}>Jogar Novamente</button>}

      

      </>

    );
  }
  
}

export default App;
