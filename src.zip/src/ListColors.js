const ListColors = (props) =>{
  

    

    return(
     <>
        

      <ul>
        {
          props.items.map((item,index) => <li onClick={()=>props.selectColor(item)} key={index} style={{backgroundColor:item}}>{item}</li>)
        }
      </ul>
      </>
    )

}


export default ListColors